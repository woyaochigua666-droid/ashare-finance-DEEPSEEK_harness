window.__ModuleLoader__.load({
  id: '@local/ashare-finance',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
    const { useCallback, useEffect, useRef, useState } = React;

    const NS = 'ashare-finance';
    const UP = '#e5484d';
    const DOWN = '#1f9d55';
    const AMBER = '#d97706';

    const ZH = {
      open: '打开 A 股财经雷达',
      close: '关闭',
      refresh: '刷新',
      title: 'A 股财经雷达',
      subtitle: '关键消息 · 财报 · 市场温度',
      news: '要闻',
      watchlist: '自选',
      updated: '更新于',
      loading: '正在抓取公开数据…',
      error: '暂时无法连接数据源',
      empty: '暂无数据，点击刷新重试',
      retry: '重试',
      disclaimer: '公开数据研究辅助，不构成投资建议',
      market: '市场温度',
      important: '重要',
      source: '数据源：东方财富 / 新浪财经 / 腾讯行情',
      openSource: '打开原文',
    };

    const EN = {
      open: 'Open A-share finance radar',
      close: 'Close',
      refresh: 'Refresh',
      title: 'A-share Finance Radar',
      subtitle: 'News · filings · market temperature',
      news: 'News',
      watchlist: 'Watchlist',
      updated: 'Updated',
      loading: 'Fetching public data…',
      error: 'Data sources are temporarily unavailable',
      empty: 'No data yet. Refresh to retry.',
      retry: 'Retry',
      disclaimer: 'Public-data research aid. Not investment advice.',
      market: 'Market temperature',
      important: 'Key',
      source: 'Sources: Eastmoney / Sina Finance / Tencent',
      openSource: 'Open source',
    };

    function fmtPct(value) {
      if (value === null || value === undefined || Number.isNaN(Number(value))) return '—';
      const numeric = Number(value);
      return `${numeric > 0 ? '+' : ''}${numeric.toFixed(2)}%`;
    }

    function fmtPrice(value) {
      if (value === null || value === undefined || Number.isNaN(Number(value))) return '—';
      return Number(value).toFixed(2);
    }

    function fmtTime(value) {
      if (!value) return '';
      const date = new Date(value);
      if (Number.isNaN(date.getTime())) return '';
      return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
    }

    function toneColor(value) {
      if (value > 0) return UP;
      if (value < 0) return DOWN;
      return 'var(--dsw-alias-label-secondary)';
    }

    function MarketIcon({ size = 22 }) {
      return h(
        'svg',
        { width: size, height: size, viewBox: '0 0 32 32', 'aria-hidden': true },
        h('rect', { x: 2, y: 2, width: 28, height: 28, rx: 8, fill: '#991b1b' }),
        h('path', { d: 'M8 22 L14 16 L18 19 L25 10', fill: 'none', stroke: '#fde68a', strokeWidth: 2.2, strokeLinecap: 'round', strokeLinejoin: 'round' }),
        h('path', { d: 'M21 10 L25 10 L25 14', fill: 'none', stroke: '#fde68a', strokeWidth: 2.2, strokeLinecap: 'round', strokeLinejoin: 'round' }),
      );
    }

    function Badge({ text, color, background }) {
      return h(
        'span',
        {
          style: {
            display: 'inline-flex',
            alignItems: 'center',
            borderRadius: 999,
            padding: '1px 7px',
            fontSize: 10,
            lineHeight: '16px',
            color,
            background,
            whiteSpace: 'nowrap',
          },
        },
        text,
      );
    }

    function RadarPanel({ t }) {
      const [open, setOpen] = useState(false);
      const [tab, setTab] = useState('news');
      const [data, setData] = useState(null);
      const [loading, setLoading] = useState(false);
      const [error, setError] = useState(null);
      const abortRef = useRef(null);

      const load = useCallback(async (force) => {
        if (abortRef.current) abortRef.current.abort();
        const controller = new AbortController();
        abortRef.current = controller;
        setLoading(true);
        setError(null);
        try {
          const response = await fetch(
            `/ashare-finance/api/briefing?refresh=${force ? '1' : '0'}`,
            { signal: controller.signal, headers: { Accept: 'application/json' } },
          );
          const payload = await response.json();
          if (!payload.ok) throw new Error(payload.error || t('error'));
          setData(payload.data);
        } catch (caught) {
          if (caught && caught.name !== 'AbortError') setError(caught.message || t('error'));
        } finally {
          if (abortRef.current === controller) {
            abortRef.current = null;
            setLoading(false);
          }
        }
      }, [t]);

      useEffect(() => {
        if (!open) return undefined;
        void load(false);
        const timer = setInterval(() => void load(false), 60_000);
        return () => {
          clearInterval(timer);
          if (abortRef.current) abortRef.current.abort();
        };
      }, [open, load]);

      useEffect(() => {
        if (!open) return undefined;
        const onKey = (event) => {
          if (event.key === 'Escape') setOpen(false);
        };
        window.addEventListener('keydown', onKey);
        return () => window.removeEventListener('keydown', onKey);
      }, [open]);

      const market = data?.market;
      const indices = market?.indices?.slice(0, 3) ?? [];
      const temperature = market?.temperature;
      const news = data?.news?.items ?? [];
      const watchlist = data?.watchlist ?? [];

      const surface = 'var(--dsw-alias-bg-overlay)';
      const layer = 'var(--dsw-alias-bg-layer-2)';
      const border = '1px solid var(--dsw-alias-border-l1)';
      const primary = 'var(--dsw-alias-label-primary)';
      const secondary = 'var(--dsw-alias-label-secondary)';
      const brand = 'var(--dsw-alias-brand-primary)';

      const button = h(
        'button',
        {
          type: 'button',
          onClick: () => setOpen((value) => !value),
          'aria-label': t('open'),
          'aria-expanded': open,
          title: t('open'),
          style: {
            position: 'fixed',
            right: 20,
            bottom: 92,
            zIndex: 80,
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            padding: '8px 13px 8px 9px',
            borderRadius: 999,
            border,
            background: surface,
            color: primary,
            boxShadow: '0 8px 28px rgba(0,0,0,0.18)',
            cursor: 'pointer',
            font: '600 12px/1.2 system-ui, -apple-system, "Segoe UI", sans-serif',
            pointerEvents: 'auto',
          },
        },
        h(MarketIcon, { size: 22 }),
        h('span', null, t('title')),
        h('span', {
          style: {
            width: 7,
            height: 7,
            borderRadius: 999,
            background: loading ? AMBER : DOWN,
            boxShadow: `0 0 0 3px ${loading ? 'rgba(217,119,6,0.16)' : 'rgba(31,157,85,0.14)'}`,
          },
        }),
      );

      if (!open) return button;

      const header = h(
        'div',
        {
          style: {
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            padding: '12px 12px 10px 14px',
            borderBottom: border,
            background: surface,
          },
        },
        h(MarketIcon, { size: 30 }),
        h(
          'div',
          { style: { minWidth: 0, flex: 1 } },
          h('div', { style: { color: primary, fontSize: 13, fontWeight: 700, letterSpacing: 0.2 } }, t('title')),
          h('div', { style: { color: secondary, fontSize: 10.5, marginTop: 2 } }, t('subtitle')),
        ),
        h(
          'button',
          {
            type: 'button',
            onClick: () => void load(true),
            disabled: loading,
            title: t('refresh'),
            style: {
              border,
              background: layer,
              color: primary,
              borderRadius: 8,
              padding: '5px 8px',
              fontSize: 11,
              cursor: loading ? 'wait' : 'pointer',
            },
          },
          loading ? '…' : t('refresh'),
        ),
        h(
          'button',
          {
            type: 'button',
            onClick: () => setOpen(false),
            title: t('close'),
            'aria-label': t('close'),
            style: {
              border: 'none',
              background: 'transparent',
              color: secondary,
              cursor: 'pointer',
              fontSize: 18,
              lineHeight: 1,
              padding: '2px 4px',
            },
          },
          '×',
        ),
      );

      const marketBlock = h(
        'div',
        { style: { padding: '10px 12px 0' } },
        h(
          'div',
          { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 7 } },
          h('span', { style: { color: secondary, fontSize: 10.5, fontWeight: 600 } }, `${t('market')} · ${temperature?.label ?? '—'}`),
          h(
            'span',
            { style: { color: secondary, fontSize: 10 } },
            data?.asOf ? `${t('updated')} ${fmtTime(data.asOf)}` : '',
          ),
        ),
        h(
          'div',
          { style: { display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: 6 } },
          indices.length > 0
            ? indices.map((index) =>
                h(
                  'div',
                  {
                    key: index.code,
                    style: {
                      background: layer,
                      border,
                      borderRadius: 9,
                      padding: '7px 8px',
                      minWidth: 0,
                    },
                  },
                  h('div', { style: { color: secondary, fontSize: 10, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } }, index.name),
                  h('div', { style: { color: toneColor(index.changePct), fontSize: 15, fontWeight: 700, marginTop: 2 } }, fmtPrice(index.price)),
                  h('div', { style: { color: toneColor(index.changePct), fontSize: 10.5, marginTop: 1 } }, fmtPct(index.changePct)),
                ),
              )
            : h('div', { style: { color: secondary, fontSize: 11, padding: 8 } }, t('empty')),
        ),
        h(
          'div',
          { style: { display: 'flex', alignItems: 'center', gap: 6, marginTop: 8 } },
          h(
            'div',
            { style: { flex: 1, height: 4, borderRadius: 999, background: layer, overflow: 'hidden' } },
            h('div', {
              style: {
                width: `${temperature?.score ?? 0}%`,
                height: '100%',
                borderRadius: 999,
                background: (temperature?.score ?? 50) >= 60 ? UP : (temperature?.score ?? 50) <= 35 ? DOWN : AMBER,
              },
            }),
          ),
          h('span', { style: { color: secondary, fontSize: 10 } }, `${temperature?.score ?? '—'}/100`),
        ),
      );

      const tabs = h(
        'div',
        { style: { display: 'flex', gap: 4, padding: '9px 12px 6px' } },
        ...[
          ['news', t('news'), news.length],
          ['watchlist', t('watchlist'), watchlist.length],
        ].map(([key, label, count]) =>
          h(
            'button',
            {
              key,
              type: 'button',
              onClick: () => setTab(key),
              style: {
                border: 'none',
                borderRadius: 999,
                padding: '4px 10px',
                fontSize: 11,
                fontWeight: 600,
                cursor: 'pointer',
                background: tab === key ? 'var(--dsw-alias-brand-primary)' : layer,
                color: tab === key ? '#fff' : secondary,
              },
            },
            `${label} ${count}`,
          ),
        ),
      );

      const newsList = h(
        'div',
        { style: { padding: '0 12px 12px' } },
        error ? h('div', { style: { color: 'var(--dsw-alias-state-error-primary)', fontSize: 11, padding: '8px 0' } }, error) : null,
        loading && news.length === 0
          ? h('div', { style: { color: secondary, fontSize: 11, padding: '18px 0', textAlign: 'center' } }, t('loading'))
          : null,
        !loading && news.length === 0
          ? h('div', { style: { color: secondary, fontSize: 11, padding: '18px 0', textAlign: 'center' } }, t('empty'))
          : null,
        news.slice(0, 8).map((item) =>
          h(
            'a',
            {
              key: `${item.title}-${item.publishedAt}`,
              href: item.url || undefined,
              target: item.url ? '_blank' : undefined,
              rel: 'noreferrer',
              style: {
                display: 'block',
                textDecoration: 'none',
                color: primary,
                padding: '8px 0',
                borderBottom: '1px solid var(--dsw-alias-border-l1)',
              },
            },
            h(
              'div',
              { style: { display: 'flex', alignItems: 'center', gap: 5, marginBottom: 3 } },
              item.importance >= 60
                ? h(Badge, { text: t('important'), color: '#fff', background: AMBER })
                : null,
              h(Badge, {
                text: item.sentiment,
                color: item.sentiment === '偏正面' ? UP : item.sentiment === '偏负面' ? DOWN : secondary,
                background: item.sentiment === '偏正面' ? 'rgba(229,72,77,0.1)' : item.sentiment === '偏负面' ? 'rgba(31,157,85,0.1)' : layer,
              }),
              h('span', { style: { color: secondary, fontSize: 9.5 } }, `${fmtTime(item.publishedAt)} · ${item.source}`),
            ),
            h('div', { style: { fontSize: 12, lineHeight: 1.45, fontWeight: 600 } }, item.title),
            item.summary
              ? h(
                  'div',
                  {
                    style: {
                      color: secondary,
                      fontSize: 10.5,
                      lineHeight: 1.45,
                      marginTop: 2,
                      display: '-webkit-box',
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: 'vertical',
                      overflow: 'hidden',
                    },
                  },
                  item.summary,
                )
              : null,
          ),
        ),
      );

      const watchList = h(
        'div',
        { style: { padding: '0 12px 12px' } },
        watchlist.length === 0
          ? h('div', { style: { color: secondary, fontSize: 11, padding: '18px 0', textAlign: 'center' } }, t('empty'))
          : watchlist.map((item) =>
              h(
                'div',
                {
                  key: item.code,
                  style: {
                    display: 'grid',
                    gridTemplateColumns: 'minmax(0, 1fr) auto auto',
                    gap: 8,
                    alignItems: 'center',
                    padding: '8px 0',
                    borderBottom: '1px solid var(--dsw-alias-border-l1)',
                  },
                },
                h(
                  'div',
                  { style: { minWidth: 0 } },
                  h('div', { style: { color: primary, fontSize: 11.5, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } }, item.error ? item.code : item.name),
                  h('div', { style: { color: secondary, fontSize: 9.5, marginTop: 1 } }, item.error ? item.error.slice(0, 30) : `${item.code} · PE ${item.pe ?? '—'}`),
                ),
                h('div', { style: { color: primary, fontSize: 12.5, fontWeight: 700 } }, item.error ? '—' : fmtPrice(item.price)),
                h('div', { style: { color: toneColor(item.changePct), fontSize: 11.5, fontWeight: 600, textAlign: 'right' } }, item.error ? '—' : fmtPct(item.changePct)),
              ),
            ),
      );

      return h(
        React.Fragment,
        null,
        button,
        h(
          'div',
          {
            role: 'dialog',
            'aria-label': t('title'),
            style: {
              position: 'fixed',
              right: 16,
              bottom: 146,
              zIndex: 81,
              width: 'min(420px, calc(100vw - 32px))',
              maxHeight: 'min(72vh, 640px)',
              display: 'flex',
              flexDirection: 'column',
              background: surface,
              border,
              borderRadius: 14,
              boxShadow: '0 24px 70px rgba(0,0,0,0.28)',
              overflow: 'hidden',
              pointerEvents: 'auto',
              font: '12px/1.4 system-ui, -apple-system, "Segoe UI", "Microsoft YaHei", sans-serif',
              backdropFilter: 'blur(12px)',
            },
          },
          header,
          h(
            'div',
            { className: 'ashare-radar-scroll', style: { overflowY: 'auto', overscrollBehavior: 'contain' } },
            marketBlock,
            tabs,
            tab === 'news' ? newsList : watchList,
          ),
          h(
            'div',
            {
              style: {
                borderTop: border,
                padding: '6px 12px 8px',
                color: secondary,
                fontSize: 9,
                lineHeight: 1.45,
                background: surface,
              },
            },
            h('div', null, t('disclaimer')),
            h('div', null, t('source')),
          ),
        ),
        h('style', null, '.ashare-radar-scroll::-webkit-scrollbar{width:6px}.ashare-radar-scroll::-webkit-scrollbar-thumb{background:var(--dsw-alias-border-l2);border-radius:999px}'),
      );
    }

    return {
      inject: ['slots', 'locale'],
      apply(ctx) {
        const t = ctx.locale.bind(NS);
        ctx.effect(() => ctx.locale.register(NS, 'zh', ZH));
        ctx.effect(() => ctx.locale.register(NS, 'zh-CN', ZH));
        ctx.effect(() => ctx.locale.register(NS, 'en', EN));
        ctx.slots.inject('shell.overlay', () =>
          ctx.slots.register(
            { name: 'shell.overlay', id: 'ashare-finance-radar', order: 90 },
            () => h(RadarPanel, { t }),
          ),
        );
      },
    };
  },
});
