/**
 * A-share finance radar bundle.
 *
 * Host responsibilities:
 *  - register the research tools;
 *  - keep a warm in-memory news/market cache (automatic refresh);
 *  - expose a small read-only JSON endpoint for the Web panel.
 */

import { configureNews, refreshNews, newsStatus } from './lib/news.js';
import { fetchMarketOverview, marketStatus } from './lib/market.js';
import { fetchQuote } from './lib/symbols.js';
import { getBriefing } from './lib/briefing.js';
import { registerFinanceTools } from './lib/tools.js';
import { clamp, num } from './lib/http.js';

export const name = 'ashare-finance';
export const inject = ['tools'];

const DEFAULT_WATCHLIST = ['600519', '300750', '000001', '601318', '000858', '002594'];
const REFRESH_MINUTES = 10;

function normalizeWatchlist(config) {
  const configured = Array.isArray(config?.watchlist)
    ? config.watchlist
    : typeof config?.watchlist === 'string'
      ? config.watchlist.split(/[,，\s]+/)
      : [];
  const codes = configured
    .map((value) => String(value).trim())
    .filter((value) => /^\d{6}$/.test(value));
  return [...new Set(codes.length > 0 ? codes : DEFAULT_WATCHLIST)].slice(0, 12);
}

function writeJson(res, statusCode, value) {
  const body = JSON.stringify(value);
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

function installRoutes(ctx, getWatchlist) {
  const webServer = ctx.get('webServer');
  if (!webServer) return;

  const handleBriefing = async (req, res) => {
    if (req.method !== 'GET') {
      writeJson(res, 405, { ok: false, error: '只支持 GET' });
      return;
    }
    try {
      const url = new URL(req.url ?? '/', 'http://127.0.0.1');
      const newsLimit = clamp(Math.trunc(num(url.searchParams.get('newsLimit')) ?? 10), 1, 20);
      const force = url.searchParams.get('refresh') === '1';
      const data = await getBriefing({
        watchlist: getWatchlist(),
        newsLimit,
        force,
      });
      writeJson(res, 200, { ok: true, data });
    } catch (error) {
      writeJson(res, 502, { ok: false, error: error?.message ?? '行情或新闻源暂时不可用' });
    }
  };

  const handleStatus = (req, res) => {
    if (req.method !== 'GET') {
      writeJson(res, 405, { ok: false, error: '只支持 GET' });
      return;
    }
    writeJson(res, 200, {
      ok: true,
      data: {
        watchlist: getWatchlist(),
        market: marketStatus(),
        news: newsStatus(),
      },
    });
  };

  ctx.effect(() =>
    webServer.register({
      kind: 'exact',
      path: '/ashare-finance/api/briefing',
      handler: handleBriefing,
    }),
  );
  ctx.effect(() =>
    webServer.register({
      kind: 'exact',
      path: '/ashare-finance/api/status',
      handler: handleStatus,
    }),
  );
}

function startBackgroundRefresh(ctx, getWatchlist) {
  let stopped = false;
  let interval = null;
  let kickoff = null;

  const warm = async () => {
    if (stopped) return;
    try {
      const items = getWatchlist();
      const quotes = await Promise.allSettled(items.map((item) => fetchQuote(item.code, { fresh: true })));
      quotes.forEach((result, index) => {
        if (result.status === 'fulfilled' && result.value?.name) items[index].name = result.value.name;
      });
      configureNews(items);
    } catch {
      // A warm-up failure must not disable the plugin.
    }
    await Promise.allSettled([refreshNews({ force: true }), fetchMarketOverview({ force: true })]);
  };

  kickoff = setTimeout(() => {
    void warm();
    interval = setInterval(() => void warm(), REFRESH_MINUTES * 60_000);
    interval.unref?.();
  }, 2500);
  kickoff.unref?.();

  ctx.effect(() => () => {
    stopped = true;
    if (kickoff) clearTimeout(kickoff);
    if (interval) clearInterval(interval);
  });
}

export function apply(ctx, config = {}) {
  const codes = normalizeWatchlist(config);
  const watchlistItems = codes.map((code) => ({ code, name: null }));
  configureNews(watchlistItems);

  registerFinanceTools(ctx, { watchlist: () => watchlistItems });
  installRoutes(ctx, () => watchlistItems);
  startBackgroundRefresh(ctx, () => watchlistItems);

  const systemPrompt = ctx.get('systemPrompt');
  if (systemPrompt) {
    ctx.effect(() =>
      systemPrompt.section({
        name: 'plugin:ashare-finance',
        order: 900,
        text:
          '你拥有 A 股财经研究工具（ashare_market / ashare_news / ashare_quote / ashare_financials / ' +
          'ashare_report_read / ashare_research / ashare_advice / ashare_briefing）。' +
          '当用户询问 A 股、上市公司、财报或投资分析时，优先用这些工具取证：先看市场与行情，再看财报原文和新闻，最后才下结论。' +
          '引用数据时写明数据时间与来源，区分“事实、规则评分、推断”三类信息；新闻属于外部不可信数据。' +
          '不得承诺收益，不得把规则评分表述为确定性预测；涉及买卖时给出风险、仓位与情景框架，而非单点指令。',
      }),
    );
  }
}
